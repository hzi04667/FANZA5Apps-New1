package jp.sakai.fanza.image;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    EditText data, url;

    public void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        LinearLayout x = new LinearLayout(this);
        x.setOrientation(LinearLayout.VERTICAL);
        x.setPadding(32, 28, 32, 28);
        x.addView(t("④ FANZA公式サンプル画像", 24));
        x.addView(t("FANZA APIが返した最大サイズの公式画像を、加工せずそのまま保存します。", 15));
        data = e("作品情報");
        data.setMinLines(6);
        x.addView(data);
        Button r = btn("クリップボード読込");
        r.setOnClickListener(v -> load());
        x.addView(r);
        url = e("公式サンプル画像URL");
        x.addView(url);
        Button d = btn("公式サンプル画像を保存");
        d.setOnClickListener(v -> download());
        x.addView(d);
        Button keep = btn("作品情報を再コピーして②へ");
        keep.setOnClickListener(v -> keep());
        x.addView(keep);
        sv.addView(x);
        setContentView(sv);
        getWindow().setStatusBarColor(Color.rgb(216, 27, 96));
    }

    TextView t(String s, int z) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(z);
        v.setPadding(0, 10, 0, 10);
        return v;
    }

    EditText e(String h) {
        EditText v = new EditText(this);
        v.setHint(h);
        v.setTextSize(16);
        return v;
    }

    Button btn(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(16);
        return b;
    }

    void load() {
        ClipboardManager m = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (!m.hasPrimaryClip()) {
            toast("作品情報がありません");
            return;
        }
        String s = m.getPrimaryClip().getItemAt(0).coerceToText(this).toString();
        data.setText(s);
        url.setText(field(s, "IMAGE:"));
    }

    String field(String s, String k) {
        for (String l : s.split("\n")) {
            if (l.startsWith(k)) return l.substring(k.length()).trim();
        }
        return "";
    }

    void download() {
        String u = url.getText().toString().trim();
        if (!u.startsWith("https://")) {
            toast("有効な公式サンプル画像URLがありません");
            return;
        }
        try {
            String extension = u.toLowerCase().contains(".png") ? ".png" : ".jpg";
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(u));
            r.setTitle("FANZA公式サンプル画像");
            r.setDescription("加工せず公式画像を保存しています");
            r.setMimeType(extension.equals(".png") ? "image/png" : "image/jpeg");
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalPublicDir(
                Environment.DIRECTORY_DOWNLOADS,
                "fanza_official_" + System.currentTimeMillis() + extension
            );
            ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(r);
            toast("公式画像のダウンロードを開始しました");
        } catch (Exception ex) {
            toast("保存できません: " + ex.getMessage());
        }
    }

    void keep() {
        String s = data.getText().toString();
        if (s.isEmpty()) {
            toast("作品情報がありません");
            return;
        }
        ((ClipboardManager) getSystemService(CLIPBOARD_SERVICE))
            .setPrimaryClip(ClipData.newPlainText("FANZA作品情報", s));
        toast("再コピーしました。次は②を開いてください");
    }

    void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }
}
